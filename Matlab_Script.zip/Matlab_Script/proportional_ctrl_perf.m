%% predict different motion amplitude
clc
clear
close
disp('"proportional_ctrl_perf_perf.m running, might take a few minutes to complete, good time for a coffe break..."');
%% build models
model_lda_SAE = get_trained_model('P1_SAE_mat',1);
model_lda_MAE = get_trained_model('P1_MAE_mat',1);
%% run classifier
disp('Testing Data : "P1_MAE_mat" on Model : "model_lda_SAE"')
[output_SAE_MAE,label] = run_trained_model('P1_MAE_mat',1,8,7,model_lda_SAE);
disp('Testing Data : "P1_MAE_mat" on Model : "model_lda_MAE"')
[output_MAE_MAE,label] = run_trained_model('P1_MAE_mat',1,8,7,model_lda_MAE);
%% sort classes (2 becomes 3 and 3 becomes 2) for proper poltting
for ip = 1:length(label)
    if (label(ip) == 2)
        label(ip) = 3;
    elseif (label(ip) == 3)
        label(ip) = 2;
    end
    if (output_SAE_MAE(ip) == 2)
        output_SAE_MAE(ip) = 3;
    elseif (output_SAE_MAE(ip) == 3)
        output_SAE_MAE(ip) = 2;
    end
    if (output_MAE_MAE(ip) == 2)
        output_MAE_MAE(ip) = 3;
    elseif (output_MAE_MAE(ip) == 3)
        output_MAE_MAE(ip) = 2;
    end
end
%% plot output
time = 0;
for it = 1:length(label)
    time(it) = (it-1)*(1/62);
end
figure
subplot(2,1,1)
plot(time,label,'Color','red')
hold on
plot(time,output_SAE_MAE,'*','Color','blue')
title('Training : SAE - Prediction : MAE')
xlim([time(1) time(length(time))])
ylim([-1 7])
subplot(2,1,2)
plot(time,label,'Color','red')
hold on
plot(time,output_MAE_MAE,'*','Color','blue')
title('Training : MAE - Prediction : MAE')
xlim([time(1) time(length(time))])
ylim([-1 7])