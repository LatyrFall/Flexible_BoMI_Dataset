clc
clear
close
%%
disp('"motion_recognition_perf.m running, might take a few minutes to complete, good time for a coffe break..."');
%% init
FV = [0 1 2]; %refers to FV1, FV2 and FV3 respectively
precision = 0;
nwin = 8; novrlp = 7;
%%
% run test
for y = 1:length(FV)
    precision(y,1) = get_lda_prediction ('P1_mat',3,FV(y),nwin,novrlp); %P1
    precision(y,2) = get_lda_prediction ('P2_mat',3,FV(y),nwin,novrlp); %P2
    precision(y,3) = get_lda_prediction ('P3_mat',3,FV(y),nwin,novrlp); %P3
    precision(y,4) = get_lda_prediction ('P4_mat',2,FV(y),nwin,novrlp); %P4
    precision(y,5) = get_lda_prediction ('P5_mat',2,FV(y),nwin,novrlp); %P5
end
figure
bar(precision')
legend('FV1','FV2','FV3')
xlabel('Participants')
ylabel('Classification Accuracy (%)')
ylim([80 105])