clc;clear;close;
%% Section IV-C) Classifier's performance
%% Section IV-C-1) / Classification Performance : 
motion_recognition_perf;
%% Section IV-C-2) / Proportional Control & Reliability : 
proportional_ctrl_perf;
%% Section IV-C-3) / Reliability over days : 
normalized_perf_over_days;