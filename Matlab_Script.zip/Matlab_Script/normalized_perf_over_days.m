%% Performance vs Time
clc
clear
close
disp('"normalized_perf_over_days.m running, might take a few minutes to complete, good time for a coffe break..."');
%%
precision = 0;
day1 = 1; dday = 2;
% % build
model_day1 = get_day_model('P1_train_day1_mat.mat',3);
model_day2 = get_day_model('P1_train_day2_mat.mat',3);
model_day3 = get_day_model('P1_train_day3_mat.mat',3);
model_day4 = get_day_model('P1_train_day4_mat.mat',3);
model_day5 = get_day_model('P1_train_day5_mat.mat',3);
% precision dday1
precision(day1,1) = run_day_model('P1_test_day1_mat.mat',3,8,7,model_day1);
precision(day1,2) = run_day_model('P1_test_day2_mat.mat',3,8,7,model_day1);
precision(day1,3) = run_day_model('P1_test_day3_mat.mat',3,8,7,model_day1);
precision(day1,4) = run_day_model('P1_test_day4_mat.mat',3,8,7,model_day1);
precision(day1,5) = run_day_model('P1_test_day5_mat.mat',3,8,7,model_day1);
% precision dday
precision(dday,1) = run_day_model('P1_test_day1_mat.mat',3,8,7,model_day1);
precision(dday,2) = run_day_model('P1_test_day2_mat.mat',3,8,7,model_day2);
precision(dday,3) = run_day_model('P1_test_day3_mat.mat',3,8,7,model_day3);
precision(dday,4) = run_day_model('P1_test_day4_mat.mat',3,8,7,model_day4);
precision(dday,5) = run_day_model('P1_test_day5_mat.mat',3,8,7,model_day5);
%%
% plot precision
figure
subplot(2,1,1)
bar(precision')
legend('day1model','ddaymodel')
xlabel('days')
ylabel('Classification Accuracy (%)')
subplot(2,1,2)
days = [1 2 3 4 5];
for dy = 1:length(days)
    normalized_precision(dy) = precision(day1,dy)/precision(dday,dy);
end
reg_line = polyval(polyfit(days,normalized_precision,1),days);
plot(days,normalized_precision,'o');
hold on
plot(days,reg_line);
xlabel('days')
ylabel('Normalized Accuracy vs days')