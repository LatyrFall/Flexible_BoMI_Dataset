function [out,label] = run_trained_model(data,nbimuused,nwin,novrlp,model_lda)
%% testing
load(data);
Nwin = nwin;
Novrlp = novrlp;
size = length(Pitch1Raw(1:end))*1/3 - 12*301; %%only the head motions
%%
if (nbimuused == 2)
    Pitch3Raw = zeros(1,length(Pitch1Raw));
    Roll3Raw = zeros(1,length(Roll1Raw));
    GYRO3X = zeros(1,length(GYRO1X));
    GYRO3Y = zeros(1,length(GYRO1Y));
    GYRO3Z = zeros(1,length(GYRO1Z));
end
%%
if (nbimuused == 2)
    shift = 301*62;
elseif (nbimuused == 3)
    shift = 301*98;
end
%%
shift = 301*98;
labeltest = 0;
%mean
meantestpitch1 = 0; meantestpitch2 = 0; meantestpitch3 = 0;
meantestroll1 = 0;  meantestroll2 = 0;  meantestroll3 = 0;
meantestyaw1 = 0;   meantestyaw2 = 0;   meantestyaw3 = 0;
meantestgyrox1 = 0; meantestgyroy1 = 0; meantestgyroz1 = 0;
meantestgyrox2 = 0; meantestgyroy2 = 0; meantestgyroz2 = 0;
meantestgyrox3 = 0; meantestgyroy3 = 0; meantestgyroz3 = 0;
%max
maxtestpitch1 = 0; maxtestpitch2 = 0; maxtestpitch3 = 0;
maxtestroll1 = 0;  maxtestroll2 = 0;  maxtestroll3 = 0;
maxtestyaw1 = 0;   maxtestyaw2 = 0;   maxtestyaw3 = 0;
maxtestgyrox1 = 0; maxtestgyroy1 = 0; maxtestgyroz1 = 0;
maxtestgyrox2 = 0; maxtestgyroy2 = 0; maxtestgyroz2 = 0;
maxtestgyrox3 = 0; maxtestgyroy3 = 0; maxtestgyroz3 = 0;
%min
mintestpitch1 = 0; mintestpitch2 = 0; mintestpitch3 = 0;
mintestroll1 = 0;  mintestroll2 = 0;  mintestroll3 = 0;
mintestyaw1 = 0;   mintestyaw2 = 0;   mintestyaw3 = 0;
mintestgyrox1 = 0; mintestgyroy1 = 0; mintestgyroz1 = 0;
mintestgyrox2 = 0; mintestgyroy2 = 0; mintestgyroz2 = 0;
mintestgyrox3 = 0; mintestgyroy3 = 0; mintestgyroz3 = 0;
%mad
madtestpitch1 = 0; madtestpitch2 = 0; madtestpitch3 = 0;
madtestroll1 = 0;  madtestroll2 = 0;  madtestroll3 = 0;
madtestyaw1 = 0;   madtestyaw2 = 0;   madtestyaw3 = 0;
madtestgyrox1 = 0; madtestgyroy1 = 0; madtestgyroz1 = 0;
madtestgyrox2 = 0; madtestgyroy2 = 0; madtestgyroz2 = 0;
madtestgyrox3 = 0; madtestgyroy3 = 0; madtestgyroz3 = 0;
%iav
iavtestpitch1 = 0; iavtestpitch2 = 0; iavtestpitch3 = 0;
iavtestroll1 = 0;  iavtestroll2 = 0;  iavtestroll3 = 0;
iavtestyaw1 = 0;   iavtestyaw2 = 0;   iavtestyaw3 = 0;
iavtestgyrox1 = 0; iavtestgyroy1 = 0; iavtestgyroz1 = 0;
iavtestgyrox2 = 0; iavtestgyroy2 = 0; iavtestgyroz2 = 0;
iavtestgyrox3 = 0; iavtestgyroy3 = 0; iavtestgyroz3 = 0;
%%

index1 = shift + 1; index2 = shift + Nwin; index = 0; indexmax = 0;
a = -1; nbwindows = 0;
while indexmax < size + shift
    a = Etiquette(index1);
    indexmax =   index1 + 300;
    while (index2 < indexmax)
        subwin = 1;
        index = index + 1;
        while subwin < 3
            index2 = index1 + 4*subwin - 1;
            labeltest (index) = Etiquette(index1);
            %mean
            meantestpitch1(index,subwin) = mean(Pitch1Raw(index1:index2));meantestpitch2(index,subwin) = mean(Pitch2Raw(index1:index2));meantestpitch3(index,subwin) = mean(Pitch3Raw(index1:index2));
            meantestroll1(index,subwin) = mean(Roll1Raw(index1:index2));meantestroll2(index,subwin) = mean(Roll2Raw(index1:index2));meantestroll3(index,subwin) = mean(Roll3Raw(index1:index2));
            meantestyaw1(index,subwin) = mean(Yaw1Raw(index1:index2));%meantestyaw2(index,subwin) = mean(Yaw2Raw(index1:index2));meantestyaw3(index,subwin) = mean(Yaw3Raw(index1:index2));
            meantestgyrox1(index,subwin) = mean(GYRO1X(index1:index2 )); meantestgyrox2(index,subwin) = mean(GYRO2X(index1 :index2 )); meantestgyrox3(index,subwin) = mean(GYRO3X(index1 :index2 ));
            meantestgyroy1(index,subwin) = mean(GYRO1Y(index1:index2 )); meantestgyroy2(index,subwin) = mean(GYRO2Y(index1 :index2 )); meantestgyroy3(index,subwin) = mean(GYRO3Y(index1 :index2 ));
            meantestgyroz1(index,subwin) = mean(GYRO1Z(index1:index2 )); meantestgyroz2(index,subwin) = mean(GYRO2Z(index1 :index2 )); meantestgyroz3(index,subwin) = mean(GYRO3Z(index1 :index2 ));
            %max
            maxtestpitch1(index,subwin) = max(Pitch1Raw(index1:index2));maxtestpitch2(index,subwin) = max(Pitch2Raw(index1:index2));maxtestpitch3(index,subwin) = max(Pitch3Raw(index1:index2));
            maxtestroll1(index,subwin) = max(Roll1Raw(index1:index2));maxtestroll2(index,subwin) = max(Roll2Raw(index1:index2));maxtestroll3(index,subwin) = max(Roll3Raw(index1:index2));
            maxtestyaw1(index,subwin) = max(Yaw1Raw(index1:index2));%maxtestyaw2(index,subwin) = max(Yaw2Raw(index1:index2));maxtestyaw3(index,subwin) = max(Yaw3Raw(index1:index2));
            maxtestgyrox1(index,subwin) = max(GYRO1X(index1:index2 )); maxtestgyrox2(index,subwin) = max(GYRO2X(index1 :index2 )); maxtestgyrox3(index,subwin) = max(GYRO3X(index1 :index2 ));
            maxtestgyroy1(index,subwin) = max(GYRO1Y(index1:index2 )); maxtestgyroy2(index,subwin) = max(GYRO2Y(index1 :index2 )); maxtestgyroy3(index,subwin) = max(GYRO3Y(index1 :index2 ));
            maxtestgyroz1(index,subwin) = max(GYRO1Z(index1:index2 )); maxtestgyroz2(index,subwin) = max(GYRO2Z(index1 :index2 )); maxtestgyroz3(index,subwin) = max(GYRO3Z(index1 :index2 ));
            %min
            mintestpitch1(index,subwin) = min(Pitch1Raw(index1:index2));mintestpitch2(index,subwin) = min(Pitch2Raw(index1:index2));mintestpitch3(index,subwin) = min(Pitch3Raw(index1:index2));
            mintestroll1(index,subwin) = min(Roll1Raw(index1:index2));mintestroll2(index,subwin) = min(Roll2Raw(index1:index2));mintestroll3(index,subwin) = min(Roll3Raw(index1:index2));
            mintestyaw1(index,subwin) = min(Yaw1Raw(index1:index2));%mintestyaw2(index,subwin) = min(Yaw2Raw(index1:index2));mintestyaw3(index,subwin) = min(Yaw3Raw(index1:index2));
            mintestgyrox1(index,subwin) = min(GYRO1X(index1:index2 )); mintestgyrox2(index,subwin) = min(GYRO2X(index1 :index2 )); mintestgyrox3(index,subwin) = min(GYRO3X(index1 :index2 ));
            mintestgyroy1(index,subwin) = min(GYRO1Y(index1:index2 )); mintestgyroy2(index,subwin) = min(GYRO2Y(index1 :index2 )); mintestgyroy3(index,subwin) = min(GYRO3Y(index1 :index2 ));
            mintestgyroz1(index,subwin) = min(GYRO1Z(index1:index2 )); mintestgyroz2(index,subwin) = min(GYRO2Z(index1 :index2 )); mintestgyroz3(index,subwin) = min(GYRO3Z(index1 :index2 ));
            %iav
            iavtestpitch1(index,subwin) = iav(Pitch1Raw(index1:index2));iavtestpitch2(index,subwin) = iav(Pitch2Raw(index1:index2));iavtestpitch3(index,subwin) = iav(Pitch3Raw(index1:index2));
            iavtestroll1(index,subwin) = iav(Roll1Raw(index1:index2));iavtestroll2(index,subwin) = iav(Roll2Raw(index1:index2));iavtestroll3(index,subwin) = iav(Roll3Raw(index1:index2));
            iavtestyaw1(index,subwin) = iav(Yaw1Raw(index1:index2));%iavtestyaw2(index,subwin) = iav(Yaw2Raw(index1:index2));iavtestyaw3(index,subwin) = iav(Yaw3Raw(index1:index2));
            iavtestgyrox1(index,subwin) = iav(GYRO1X(index1:index2 )); iavtestgyrox2(index,subwin) = iav(GYRO2X(index1 :index2 )); iavtestgyrox3(index,subwin) = iav(GYRO3X(index1 :index2 ));
            iavtestgyroy1(index,subwin) = iav(GYRO1Y(index1:index2 )); iavtestgyroy2(index,subwin) = iav(GYRO2Y(index1 :index2 )); iavtestgyroy3(index,subwin) = iav(GYRO3Y(index1 :index2 ));
            iavtestgyroz1(index,subwin) = iav(GYRO1Z(index1:index2 )); iavtestgyroz2(index,subwin) = iav(GYRO2Z(index1 :index2 )); iavtestgyroz3(index,subwin) = iav(GYRO3Z(index1 :index2 ));
            subwin = subwin + 1;
        end
        index1 = index1 + (Nwin - Novrlp);
        index2 = index1 + Nwin - 1;
        nbwindows = nbwindows + 1;
    end
    index1 = indexmax + 1;
    index2 = index1 + Nwin - 1;
    nbwindows = 0;
end
%message = strcat('Test: Last Index = ',num2str(index2-Nwin));
%disp(message);

input_imu1 = [meantestpitch1,maxtestpitch1,mintestpitch1,iavtestpitch1,meantestroll1,maxtestroll1,mintestroll1,iavtestroll1,meantestyaw1,maxtestyaw1,mintestyaw1,iavtestyaw1,meantestgyrox1,maxtestgyrox1,mintestgyrox1,iavtestgyrox1,meantestgyroy1,maxtestgyroy1,mintestgyroy1,iavtestgyroy1,meantestgyroz1,maxtestgyroz1,mintestgyroz1,iavtestgyroz1];
input_imu2 = [meantestpitch2,maxtestpitch2,mintestpitch2,iavtestpitch2,meantestroll2,maxtestroll2,mintestroll2,iavtestroll2,meantestgyrox2,maxtestgyrox2,mintestgyrox2,iavtestgyrox2,meantestgyroy2,maxtestgyroy2,mintestgyroy2,iavtestgyroy2,meantestgyroz2,maxtestgyroz2,mintestgyroz2,iavtestgyroz2];
input_imu3 = [meantestpitch3,maxtestpitch3,mintestpitch3,iavtestpitch3,meantestroll3,maxtestroll3,mintestroll3,iavtestroll3,meantestgyrox3,maxtestgyrox3,mintestgyrox3,iavtestgyrox3,meantestgyroy3,maxtestgyroy3,mintestgyroy3,iavtestgyroy3,meantestgyroz3,maxtestgyroz3,mintestgyroz3,iavtestgyroz3];

if (nbimuused == 1)
    input = [input_imu1];
elseif (nbimuused == 2)
    input = [input_imu1,input_imu2];
elseif (nbimuused == 3)
    input = [input_imu1,input_imu2,input_imu3];
end

disp('Testing: Feature Extraction Done')
%%
error = 0; output = 0;
for t = 1:length(input)
    output(t) = predict(model_lda,input(t,:));
    if output(t) ~= labeltest(t)
        error = error + 1;
    end
end

out = output;
label = labeltest;

acc = (1-(error/length(output)))*100;
message = strcat('Accuracy LDA = ',num2str(acc),' %');
disp(message)
precision = acc;
end

